writing to md
